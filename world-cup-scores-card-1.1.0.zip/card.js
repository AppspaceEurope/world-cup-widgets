"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
/* shared/js/wc-dom.js */
/* wc-dom.js — DOM + formatting helpers. Registers WC.dom.
 * Data is always set via textContent (never innerHTML) — XSS-safe with feed strings. */
(function () {
  'use strict';

  var WC = window.WC = window.WC || {};
  function el(tag, opts, children) {
    var node = document.createElement(tag);
    opts = opts || {};
    if (typeof opts === 'string') {
      node.className = opts;
    } else {
      if (opts.class) node.className = opts.class;
      if (opts.text != null) node.textContent = String(opts.text);
      if (opts.title) node.title = opts.title;
      if (opts.role) node.setAttribute('role', opts.role);
      if (opts.tabindex != null) node.setAttribute('tabindex', String(opts.tabindex));
      if (opts.aria) {
        Object.keys(opts.aria).forEach(function (k) {
          node.setAttribute('aria-' + k, String(opts.aria[k]));
        });
      }
      if (opts.attrs) {
        Object.keys(opts.attrs).forEach(function (k) {
          node.setAttribute(k, String(opts.attrs[k]));
        });
      }
      if (opts.style) node.setAttribute('style', opts.style);
      if (opts.on) {
        Object.keys(opts.on).forEach(function (evt) {
          node.addEventListener(evt, opts.on[evt]);
        });
      }
    }
    if (children) {
      (Array.isArray(children) ? children : [children]).forEach(function (c) {
        if (c == null) return;
        node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
      });
    }
    return node;
  }
  function clear(node) {
    while (node && node.firstChild) node.removeChild(node.firstChild);
    return node;
  }

  // Kick-off time in the viewer's local timezone, e.g. "20:00"
  function fmtKickoff(iso) {
    try {
      return new Intl.DateTimeFormat(undefined, {
        hour: '2-digit',
        minute: '2-digit'
      }).format(new Date(iso));
    } catch (e) {
      return '';
    }
  }

  // "Today" / "Tomorrow" / "Sat 14 Jun" relative to local now.
  function fmtDayLabel(date) {
    var d = new Date(date);
    var now = new Date();
    var startOf = function startOf(x) {
      return new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
    };
    var diffDays = Math.round((startOf(d) - startOf(now)) / 86400000);
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    if (diffDays === -1) return 'Yesterday';
    try {
      return new Intl.DateTimeFormat(undefined, {
        weekday: 'short',
        day: 'numeric',
        month: 'short'
      }).format(d);
    } catch (e) {
      return d.toDateString();
    }
  }

  // Short chip label: "Today" / "Sat 14"
  function fmtChip(date) {
    var d = new Date(date);
    var now = new Date();
    var startOf = function startOf(x) {
      return new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
    };
    var diffDays = Math.round((startOf(d) - startOf(now)) / 86400000);
    if (diffDays === 0) return 'Today';
    try {
      return new Intl.DateTimeFormat(undefined, {
        weekday: 'short',
        day: 'numeric'
      }).format(d);
    } catch (e) {
      return d.toDateString();
    }
  }

  // "Updated 14:02" or "Updated 3 min ago"
  function relTime(ts) {
    if (!ts) return '';
    var mins = Math.round((Date.now() - ts) / 60000);
    if (mins < 1) return 'Updated just now';
    if (mins < 60) return 'Updated ' + mins + ' min ago';
    try {
      return 'Updated ' + new Intl.DateTimeFormat(undefined, {
        hour: '2-digit',
        minute: '2-digit'
      }).format(new Date(ts));
    } catch (e) {
      return '';
    }
  }

  // yyyymmdd for the ESPN ?dates= param, based on local date + offset days.
  function ymdOffset(offsetDays) {
    var d = new Date();
    d.setDate(d.getDate() + (offsetDays || 0));
    return d.getFullYear().toString() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
  }
  WC.dom = {
    el: el,
    clear: clear,
    fmtKickoff: fmtKickoff,
    fmtDayLabel: fmtDayLabel,
    fmtChip: fmtChip,
    relTime: relTime,
    ymdOffset: ymdOffset
  };
})();
;
/* shared/js/wc-cache.js */
/* wc-cache.js — localStorage cache with in-memory fallback. Registers WC.cache.
 * Sandboxed iframes can throw on localStorage access, so every call is guarded. */
(function () {
  'use strict';

  var WC = window.WC = window.WC || {};
  var mem = {};
  var ls = null;
  try {
    var t = '__wc_probe__';
    window.localStorage.setItem(t, '1');
    window.localStorage.removeItem(t);
    ls = window.localStorage;
  } catch (e) {
    ls = null; // fall back to in-memory only
  }
  function get(key) {
    try {
      if (ls) {
        var raw = ls.getItem(key);
        return raw ? JSON.parse(raw) : null;
      }
    } catch (e) {/* fall through */}
    return mem[key] || null;
  }
  function set(key, data) {
    var entry = {
      data: data,
      savedAt: Date.now()
    };
    mem[key] = entry;
    try {
      if (ls) ls.setItem(key, JSON.stringify(entry));
    } catch (e) {/* quota / disabled — in-memory copy still set */}
    return entry;
  }

  // Drop scoreboard entries older than maxAgeDays to keep storage tidy.
  function prune(prefix, maxAgeDays) {
    if (!ls) return;
    var cutoff = Date.now() - (maxAgeDays || 3) * 86400000;
    try {
      var toRemove = [];
      for (var i = 0; i < ls.length; i++) {
        var k = ls.key(i);
        if (k && k.indexOf(prefix) === 0) {
          var v = JSON.parse(ls.getItem(k));
          if (v && v.savedAt && v.savedAt < cutoff) toRemove.push(k);
        }
      }
      toRemove.forEach(function (k) {
        ls.removeItem(k);
      });
    } catch (e) {/* ignore */}
  }
  WC.cache = {
    get: get,
    set: set,
    prune: prune,
    hasLocalStorage: !!ls
  };
})();
;
/* shared/js/espn-adapter.js */
/* espn-adapter.js — the ONLY module that knows ESPN's response shapes.
 * Swap this file to change data feeds. Registers WC.espn.
 *
 * Normalised models (everything else in the widgets depends on these, not ESPN):
 *   Match = {
 *     id, dateUtc, state: 'pre'|'in'|'post', statusDetail, clock, isLive,
 *     groupNote, venue: { name, city, country },
 *     home/away: { id, name, shortName, abbr, logo, score, shootout, winner, isTbd },
 *     events: [{ kind:'goal'|'card', minute, teamId, player, ownGoal, penalty, card:'yellow'|'red' }]
 *   }
 *   Standings = { groups: [{ name, letter, entries: [{
 *       team:{id,name,abbr,logo}, rank, played, won, drawn, lost, gf, ga, gd, points, note, qualifies
 *   }] }] }
 */
(function () {
  'use strict';

  var WC = window.WC = window.WC || {};
  var SITE = 'https://site.api.espn.com/apis/site/v2/sports/soccer/fifa.world';
  var CORE = 'https://site.api.espn.com/apis/v2/sports/soccer/fifa.world';
  var cfg = {
    mockName: null
  };

  // ?mock=group-stage drives the adapter from shared/mock/ instead of ESPN (dev only).
  function configureFromUrl() {
    try {
      var params = new URLSearchParams(window.location.search);
      cfg.mockName = params.get('mock');
    } catch (e) {
      cfg.mockName = null;
    }
    return cfg;
  }
  function fetchJson(url) {
    return fetch(url, {
      headers: {
        Accept: 'application/json'
      }
    }).then(function (res) {
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.json();
    });
  }

  // --- Scoreboard ---------------------------------------------------------

  function scoreboardUrl(yyyymmdd) {
    if (cfg.mockName) {
      // Map the URL date back to a fixture name where it makes sense.
      return 'shared/mock/scoreboard-' + cfg.mockName + '.json';
    }
    return SITE + '/scoreboard' + (yyyymmdd ? '?dates=' + yyyymmdd : '');
  }
  function isTbd(team) {
    return !(team && team.logo);
  }
  function teamLogo(team) {
    if (!team) return '';
    if (team.logo) return team.logo;
    if (team.logos && team.logos[0] && team.logos[0].href) return team.logos[0].href;
    return '';
  }

  // Scoreboard gives a plain score; the team-schedule endpoint gives a {$ref}
  // object instead — treat any non-primitive score as absent.
  function plainScore(s) {
    if (s == null) return '';
    if (_typeof(s) === 'object') return s.displayValue != null ? String(s.displayValue) : '';
    return String(s);
  }
  function normalizeCompetitor(c) {
    var t = c && c.team || {};
    return {
      id: t.id || '',
      name: t.displayName || t.name || 'TBD',
      shortName: t.shortDisplayName || t.abbreviation || t.displayName || 'TBD',
      abbr: t.abbreviation || '',
      logo: teamLogo(t),
      score: plainScore(c && c.score),
      shootout: plainScore(c && c.shootoutScore),
      winner: !!(c && c.winner),
      isTbd: isTbd(t)
    };
  }
  function normalizeEvents(details) {
    var out = [];
    (details || []).forEach(function (d) {
      try {
        var typeText = d.type && d.type.text || '';
        var minute = d.clock && d.clock.displayValue || '';
        var teamId = d.team && d.team.id || '';
        var who = d.athletesInvolved && d.athletesInvolved[0] && d.athletesInvolved[0].displayName || '';
        if (d.scoringPlay) {
          out.push({
            kind: 'goal',
            minute: minute,
            teamId: teamId,
            player: who,
            ownGoal: !!d.ownGoal,
            penalty: !!d.penaltyKick
          });
        } else if (/card/i.test(typeText)) {
          out.push({
            kind: 'card',
            minute: minute,
            teamId: teamId,
            player: who,
            card: /red/i.test(typeText) ? 'red' : 'yellow'
          });
        }
      } catch (e) {/* skip malformed detail */}
    });
    return out;
  }
  function groupNoteFrom(altGameNote) {
    if (!altGameNote) return '';
    var m = /Group\s+([A-L])/i.exec(altGameNote);
    return m ? 'Group ' + m[1].toUpperCase() : '';
  }
  function normalizeMatch(ev) {
    try {
      var comp = ev.competitions && ev.competitions[0] || {};
      var status = ev.status || comp.status || {};
      var type = status.type || {};
      var state = type.state || 'pre'; // pre | in | post
      var competitors = comp.competitors || [];
      var homeC = competitors.filter(function (c) {
        return c.homeAway === 'home';
      })[0] || competitors[0];
      var awayC = competitors.filter(function (c) {
        return c.homeAway === 'away';
      })[0] || competitors[1];
      var home = normalizeCompetitor(homeC);
      var away = normalizeCompetitor(awayC);
      var venue = comp.venue || ev.venue || {};
      var addr = venue.address || {};
      return {
        id: ev.id || comp.id || '',
        dateUtc: ev.date || comp.date || '',
        state: state,
        statusDetail: type.shortDetail || type.description || '',
        clock: status.displayClock || '',
        isLive: state === 'in',
        groupNote: groupNoteFrom(comp.altGameNote),
        venue: {
          name: venue.fullName || '',
          city: addr.city || '',
          country: addr.country || ''
        },
        home: home,
        away: away,
        events: normalizeEvents(comp.details)
      };
    } catch (e) {
      return null; // a single bad match never breaks the day
    }
  }
  function fetchScoreboard(yyyymmdd) {
    return fetchJson(scoreboardUrl(yyyymmdd)).then(function (data) {
      var matches = (data.events || []).map(normalizeMatch).filter(Boolean).sort(function (a, b) {
        return new Date(a.dateUtc) - new Date(b.dateUtc);
      });
      return {
        date: yyyymmdd || '',
        matches: matches
      };
    });
  }

  // --- Standings ----------------------------------------------------------

  function standingsUrl() {
    if (cfg.mockName) return 'shared/mock/standings.json';
    return CORE + '/standings';
  }
  function statByType(stats, type) {
    var s = (stats || []).filter(function (x) {
      return x.type === type;
    })[0];
    return s ? s.displayValue : '';
  }
  function numStat(stats, type) {
    var v = statByType(stats, type);
    var n = parseInt(v, 10);
    return isNaN(n) ? 0 : n;
  }
  function normalizeEntry(en) {
    var t = en.team || {};
    var note = en.note || null;
    return {
      team: {
        id: t.id || '',
        name: t.displayName || t.name || 'TBD',
        abbr: t.abbreviation || '',
        logo: teamLogo(t)
      },
      rank: numStat(en.stats, 'rank'),
      played: numStat(en.stats, 'gamesplayed'),
      won: numStat(en.stats, 'wins'),
      drawn: numStat(en.stats, 'ties'),
      lost: numStat(en.stats, 'losses'),
      gf: numStat(en.stats, 'pointsfor'),
      ga: numStat(en.stats, 'pointsagainst'),
      gd: statByType(en.stats, 'pointdifferential') || '0',
      points: numStat(en.stats, 'points'),
      note: note ? note.description || '' : '',
      qualifies: !!(note && note.rank && note.rank <= 2)
    };
  }
  function letterFromName(name) {
    var m = /Group\s+([A-L])/i.exec(name || '');
    return m ? m[1].toUpperCase() : name || '';
  }
  function fetchStandings() {
    return fetchJson(standingsUrl()).then(function (data) {
      var groups = (data.children || []).map(function (g) {
        var entries = (g.standings && g.standings.entries || []).map(normalizeEntry).sort(function (a, b) {
          return (a.rank || 99) - (b.rank || 99);
        });
        return {
          name: g.name || '',
          letter: letterFromName(g.name),
          entries: entries
        };
      });
      return {
        groups: groups
      };
    });
  }

  // --- Team schedule (previous results + upcoming fixtures) ---------------
  // ESPN's /teams/{id}/schedule only returns a team's *played* games for the
  // World Cup, so it never shows upcoming fixtures. Instead pull a date-range
  // scoreboard covering the tournament window and filter for the team — that
  // carries both results and future fixtures.

  function ymd(offsetDays) {
    var d = new Date();
    d.setDate(d.getDate() + offsetDays);
    return d.getFullYear().toString() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
  }
  function teamScheduleUrl() {
    if (cfg.mockName) return 'shared/mock/team-schedule.json';
    // Rolling window wide enough to cover the whole tournament from any vantage.
    return SITE + '/scoreboard?dates=' + ymd(-40) + '-' + ymd(50) + '&limit=400';
  }
  function fetchTeamSchedule(teamId) {
    var id = String(teamId);
    return fetchJson(teamScheduleUrl()).then(function (data) {
      var all = (data.events || []).map(normalizeMatch).filter(Boolean);
      var mine = all.filter(function (m) {
        return m.home.id === id || m.away.id === id;
      });
      var matches = mine.length ? mine : all; // mock fixtures use a fixed team
      var past = matches.filter(function (m) {
        return m.state === 'post';
      }).sort(function (a, b) {
        return new Date(b.dateUtc) - new Date(a.dateUtc);
      }); // newest first
      var future = matches.filter(function (m) {
        return m.state !== 'post';
      }).sort(function (a, b) {
        return new Date(a.dateUtc) - new Date(b.dateUtc);
      }); // soonest first
      return {
        team: {
          id: id,
          name: '',
          logo: ''
        },
        past: past,
        future: future
      };
    });
  }

  // --- Match summary (lineups / formation) --------------------------------

  function summaryUrl(eventId) {
    if (cfg.mockName) return 'shared/mock/match-summary.json';
    return SITE + '/summary?event=' + eventId;
  }
  function fetchMatchSummary(eventId) {
    return fetchJson(summaryUrl(eventId)).then(function (data) {
      var lineups = (data.rosters || []).map(function (r) {
        var players = (r.roster || []).map(function (p) {
          var a = p.athlete || {};
          return {
            name: a.displayName || a.shortName || a.lastName || '',
            pos: p.position && p.position.abbreviation || '',
            jersey: p.jersey != null ? String(p.jersey) : '',
            starter: !!p.starter
          };
        });
        return {
          teamId: r.team && r.team.id || '',
          name: r.team && r.team.displayName || '',
          formation: r.formation || '',
          starters: players.filter(function (x) {
            return x.starter;
          }),
          subs: players.filter(function (x) {
            return !x.starter;
          })
        };
      });
      return {
        lineups: lineups
      };
    }).catch(function () {
      return {
        lineups: []
      };
    });
  }
  WC.espn = {
    configureFromUrl: configureFromUrl,
    fetchScoreboard: fetchScoreboard,
    fetchStandings: fetchStandings,
    fetchTeamSchedule: fetchTeamSchedule,
    fetchMatchSummary: fetchMatchSummary,
    _config: cfg
  };
})();
;
/* shared/js/wc-poller.js */
/* wc-poller.js — fast/slow polling engine. Registers WC.poller.
 * Picks the next interval from the just-fetched data, pauses when the tab is
 * hidden, and jitters ±10% so a fleet of devices doesn't hammer ESPN in lockstep. */
(function () {
  'use strict';

  var WC = window.WC = window.WC || {};
  function create(opts) {
    var fetchFn = opts.fetchFn; // () => Promise<data>
    var isFastFn = opts.isFastFn || function () {
      return false;
    };
    var fastMs = opts.fastMs || 60000;
    var slowMs = opts.slowMs || 600000;
    var onData = opts.onData || function () {};
    var onError = opts.onError || function () {};
    var timer = null;
    var stopped = false;
    var inFlight = false;
    function jitter(ms) {
      var spread = ms * 0.1;
      // deterministic-ish jitter without Math.random (varies by time)
      var f = Date.now() % 1000 / 1000; // 0..1
      return Math.round(ms - spread + f * spread * 2);
    }
    function schedule(ms) {
      clearTimeout(timer);
      if (stopped) return;
      timer = setTimeout(tick, jitter(ms));
    }
    function tick() {
      if (stopped || inFlight) return;
      if (document.hidden) {
        schedule(slowMs);
        return;
      }
      inFlight = true;
      Promise.resolve(fetchFn()).then(function (data) {
        inFlight = false;
        if (stopped) return;
        onData(data);
        schedule(isFastFn(data) ? fastMs : slowMs);
      }).catch(function (err) {
        inFlight = false;
        if (stopped) return;
        onError(err);
        schedule(slowMs); // back off on error
      });
    }
    function onVisible() {
      if (!stopped && !document.hidden) refreshNow();
    }
    document.addEventListener('visibilitychange', onVisible);
    function start() {
      stopped = false;
      tick();
    }
    function stop() {
      stopped = true;
      clearTimeout(timer);
      document.removeEventListener('visibilitychange', onVisible);
    }
    function refreshNow() {
      clearTimeout(timer);
      tick();
    }
    return {
      start: start,
      stop: stop,
      refreshNow: refreshNow
    };
  }
  WC.poller = {
    create: create
  };
})();
;
/* shared/js/wc-teams.js */
/* wc-teams.js — team badge rendering. Registers WC.teams.
 * Logo <img> with graceful fallback to an initials disc; TBD teams get a
 * neutral dashed placeholder showing the seed code ("1C"). */
(function () {
  'use strict';

  var WC = window.WC = window.WC || {};
  var el = WC.dom.el;
  function initials(team) {
    var src = team.abbr || team.shortName || team.name || '';
    return src.slice(0, 3).toUpperCase();
  }

  // size in px (square)
  function badge(team, size) {
    size = size || 28;
    var styleSize = 'width:' + size + 'px;height:' + size + 'px;';
    if (team.isTbd) {
      return el('span', {
        class: 'wc-badge is-tbd',
        style: styleSize,
        text: team.abbr || '–',
        title: team.name,
        aria: {
          label: team.name
        }
      });
    }
    var wrap = el('span', {
      class: 'wc-badge',
      style: styleSize,
      aria: {
        label: team.name
      }
    });
    if (team.logo) {
      var img = el('img', {
        attrs: {
          src: team.logo,
          alt: '',
          loading: 'lazy'
        }
      });
      img.addEventListener('error', function () {
        WC.dom.clear(wrap);
        wrap.textContent = initials(team);
      });
      wrap.appendChild(img);
    } else {
      wrap.textContent = initials(team);
    }
    return wrap;
  }
  WC.teams = {
    badge: badge,
    initials: initials
  };
})();
;
/* scores-card/js/card-config.js */
/* card-config.js — config for the World Cup scores card. Registers WC.cardConfig.
 *
 * A card has no widget-api. Config precedence (low → high):
 *   built-in DEFAULTS  →  model.json (packaged defaults)  →  ?cfg= (dev/query)
 *   →  host api.init (the player/Console may post the user's resolved model).
 *
 * The card is fully functional on DEFAULTS alone (live scores need no config),
 * so we never block on the host: load() resolves immediately with what we have
 * and calls onUpdate() if a host message arrives later. */
(function () {
  'use strict';

  var WC = window.WC = window.WC || {};
  var DEFAULTS = {
    title: 'World Cup',
    accentColor: ''
  };

  // An input value can be a primitive or a richtext object ({ text }).
  function valueOf(input) {
    var v = input && input.value;
    if (v && _typeof(v) === 'object' && 'text' in v) return v.text;
    return v;
  }
  function fromInputs(inputs, into) {
    (inputs || []).forEach(function (i) {
      if (i && i.name != null) {
        var v = valueOf(i);
        if (v !== undefined && v !== null && v !== '') into[i.name] = v;
      }
    });
    return into;
  }

  // Host api.init payloads vary; pull a config object from the likely shapes.
  function fromHostMessage(msg) {
    if (!msg || _typeof(msg) !== 'object') return null;
    var c = msg.config || msg;
    var model = c.model || msg.model;
    if (model && Array.isArray(model.inputs)) return fromInputs(model.inputs, {});
    if (c && Array.isArray(c.inputs)) return fromInputs(c.inputs, {});
    if (c && (c.title != null || c.accentColor != null)) {
      var o = {};
      if (c.title != null) o.title = c.title;
      if (c.accentColor != null) o.accentColor = c.accentColor;
      return o;
    }
    return null;
  }
  function parseQuery(cfg) {
    try {
      var raw = new URLSearchParams(window.location.search).get('cfg');
      if (!raw) return;
      var json = /^[\{\[]/.test(raw) ? raw : atob(raw);
      Object.assign(cfg, JSON.parse(json));
    } catch (e) {/* ignore bad ?cfg= */}
  }

  // Returns a Promise<config>. onUpdate(config) fires if the host posts config later.
  function load(onUpdate) {
    var cfg = Object.assign({}, DEFAULTS);

    // Tell the host we're ready (harmless if no host is listening).
    try {
      if (window.parent && window.parent !== window) window.parent.postMessage({
        message: 'onapiready'
      }, '*');
    } catch (e) {}
    window.addEventListener('message', function (ev) {
      var data = ev && ev.data;
      if (!data || data.message !== 'api.init' && data.message !== 'api.updatemodel') return;
      var hostCfg = fromHostMessage(data);
      if (hostCfg) {
        Object.assign(cfg, hostCfg);
        if (typeof onUpdate === 'function') onUpdate(Object.assign({}, cfg));
      }
    });
    return fetch('model.json', {
      headers: {
        Accept: 'application/json'
      }
    }).then(function (r) {
      return r.ok ? r.json() : null;
    }).catch(function () {
      return null;
    }).then(function (model) {
      if (model && Array.isArray(model.inputs)) fromInputs(model.inputs, cfg);
      parseQuery(cfg); // query overrides packaged defaults
      return Object.assign({}, cfg);
    });
  }
  WC.cardConfig = {
    load: load,
    DEFAULTS: DEFAULTS
  };
})();
;
/* scores-card/js/state.js */
/* state.js — turns the ESPN scoreboard into the card's view model.
 * Registers WC.cardState.
 *
 * fetchView(): today's matches; if today has none, scans forward to the next
 *   matchday (so between match days the card shows "what's next").
 * classify(): splits into live / upcoming / recent and picks the content mode. */
(function () {
  'use strict';

  var WC = window.WC = window.WC || {};
  var MAX_FORWARD_DAYS = 16; // tournament gaps are short; cap the look-ahead

  function fetchDay(offset) {
    return WC.espn.fetchScoreboard(WC.dom.ymdOffset(offset)).then(function (r) {
      return {
        offset: offset,
        matches: r && r.matches || []
      };
    });
  }
  function scanForward(offset) {
    return fetchDay(offset).then(function (day) {
      if (day.matches.length || offset >= MAX_FORWARD_DAYS) return day;
      return scanForward(offset + 1);
    });
  }
  function fetchView() {
    return fetchDay(0).then(function (today) {
      if (today.matches.length) return today;
      return scanForward(1); // nothing today → next matchday
    });
  }
  function byDateAsc(a, b) {
    return new Date(a.dateUtc) - new Date(b.dateUtc);
  }
  function byDateDesc(a, b) {
    return new Date(b.dateUtc) - new Date(a.dateUtc);
  }
  function classify(day) {
    var matches = day && day.matches || [];
    var offset = day && day.offset || 0;
    var live = matches.filter(function (m) {
      return m.state === 'in';
    });
    var upcoming = matches.filter(function (m) {
      return m.state === 'pre';
    }).sort(byDateAsc);
    var recent = matches.filter(function (m) {
      return m.state === 'post';
    }).sort(byDateDesc);
    var mode = live.length ? 'live' : offset === 0 ? 'today' : 'next';
    var dayLabel;
    if (mode === 'live') dayLabel = 'Live';else if (mode === 'today') dayLabel = 'Today';else {
      var first = upcoming[0] || matches[0];
      dayLabel = 'Next up · ' + (first ? WC.dom.fmtDayLabel(new Date(first.dateUtc)) : 'soon');
    }
    return {
      mode: mode,
      dayLabel: dayLabel,
      live: live,
      upcoming: upcoming,
      recent: recent,
      offset: offset
    };
  }

  // Live-ish: a match in play, or a pre-match within 10 min of kick-off.
  function isFast(day) {
    var matches = day && day.matches || [];
    var now = Date.now();
    return matches.some(function (m) {
      if (m.state === 'in') return true;
      if (m.state === 'pre' && m.dateUtc) {
        var diff = new Date(m.dateUtc).getTime() - now;
        return diff > 0 && diff < 10 * 60000;
      }
      return false;
    });
  }
  WC.cardState = {
    fetchView: fetchView,
    classify: classify,
    isFast: isFast
  };
})();
;
/* scores-card/js/render.js */
/* render.js — builds the card DOM from a view model. Registers WC.cardRender.
 * Layout (hero size, columns vs stack, compact) is handled by CSS media/orientation
 * queries; this module only decides WHAT goes in the hero vs the secondary strip.
 *
 *   LIVE  → hero = the focused live match (big); secondary = Up next + Recent.
 *   TODAY/NEXT → hero = today's/next matchday's upcoming fixtures; secondary = Recent. */
(function () {
  'use strict';

  var WC = window.WC = window.WC || {};
  var el = WC.dom.el;
  function teamName(t) {
    return t && (t.shortName || t.name) || 'TBD';
  }

  // Crest sized by CSS (rem) per context — mirrors wc-teams.badge but no inline px.
  function crest(team, ctxClass) {
    var wrap = el('span', {
      class: 'wc-badge ' + (ctxClass || ''),
      aria: {
        label: teamName(team)
      }
    });
    if (team.isTbd) {
      wrap.classList.add('is-tbd');
      wrap.textContent = team.abbr || '–';
      return wrap;
    }
    if (team.logo) {
      var img = el('img', {
        attrs: {
          src: team.logo,
          alt: '',
          loading: 'lazy'
        }
      });
      img.addEventListener('error', function () {
        WC.dom.clear(wrap);
        wrap.textContent = WC.teams.initials(team);
      });
      wrap.appendChild(img);
    } else {
      wrap.textContent = WC.teams.initials(team);
    }
    return wrap;
  }
  function goalsFor(match, teamId) {
    return (match.events || []).filter(function (e) {
      return e.kind === 'goal' && e.teamId === teamId;
    });
  }
  function scorerText(g) {
    var suffix = [];
    if (g.minute) suffix.push(g.minute);
    if (g.penalty) suffix.push('pen');
    if (g.ownGoal) suffix.push('OG');
    return (g.player || 'Goal') + (suffix.length ? ' ' + suffix.join(' ') : '');
  }
  function scorerList(match, teamId, alignClass) {
    var list = el('ul', 'hl-scorers ' + (alignClass || ''));
    goalsFor(match, teamId).forEach(function (g) {
      list.appendChild(el('li', {
        text: scorerText(g)
      }));
    });
    return list;
  }

  // --- Hero: live match ---------------------------------------------------
  function liveHero(m) {
    var hero = el('div', 'hero-live');
    var row = el('div', 'hl-row');
    var home = el('div', 'hl-side is-home');
    home.appendChild(crest(m.home, 'crest-hero'));
    home.appendChild(el('div', {
      class: 'hl-name',
      text: teamName(m.home)
    }));
    var center = el('div', 'hl-center');
    center.appendChild(el('div', {
      class: 'hl-score',
      text: (m.home.score || '0') + ' – ' + (m.away.score || '0')
    }));
    center.appendChild(el('div', {
      class: 'hl-clock',
      text: m.clock || m.statusDetail || 'LIVE'
    }));
    var away = el('div', 'hl-side is-away');
    away.appendChild(crest(m.away, 'crest-hero'));
    away.appendChild(el('div', {
      class: 'hl-name',
      text: teamName(m.away)
    }));
    row.appendChild(home);
    row.appendChild(center);
    row.appendChild(away);
    hero.appendChild(row);
    var scorers = el('div', 'hl-scorers-row');
    scorers.appendChild(scorerList(m, m.home.id, 'align-left'));
    scorers.appendChild(scorerList(m, m.away.id, 'align-right'));
    hero.appendChild(scorers);
    var meta = [m.groupNote, m.venue && m.venue.name].filter(Boolean).join(' · ');
    if (meta) hero.appendChild(el('div', {
      class: 'hl-meta',
      text: meta
    }));
    return hero;
  }

  // --- Hero: upcoming fixtures (no live) ----------------------------------
  function fixtureCard(m, featured) {
    var card = el('div', 'fx-card' + (featured ? ' is-featured' : ''));
    card.appendChild(el('div', {
      class: 'fx-time',
      text: WC.dom.fmtKickoff(m.dateUtc)
    }));
    var teams = el('div', 'fx-teams');
    [m.home, m.away].forEach(function (t, i) {
      var line = el('div', 'fx-team');
      line.appendChild(crest(t, 'crest-fx'));
      line.appendChild(el('span', {
        class: 'fx-team-name',
        text: teamName(t)
      }));
      teams.appendChild(line);
      if (i === 0) teams.appendChild(el('div', {
        class: 'fx-v',
        text: 'v'
      }));
    });
    card.appendChild(teams);
    if (m.groupNote) card.appendChild(el('div', {
      class: 'fx-group',
      text: m.groupNote
    }));
    return card;
  }
  function fixturesHero(view) {
    var hero = el('div', 'hero-fixtures');
    if (!view.upcoming.length) {
      hero.appendChild(el('div', {
        class: 'card-empty',
        text: 'No upcoming matches'
      }));
      return hero;
    }
    var grid = el('div', 'fx-grid');
    // Cap at 4 so the bigger cards stay a tidy, symmetric block at any size
    // (more than that overflows a short zone; the soonest 4 is the glance value).
    view.upcoming.slice(0, 4).forEach(function (m, i) {
      grid.appendChild(fixtureCard(m, i === 0));
    });
    hero.appendChild(grid);
    return hero;
  }

  // --- Secondary rows -----------------------------------------------------
  function fixtureRow(m) {
    var row = el('div', 'sx-row');
    row.appendChild(el('span', {
      class: 'sx-time',
      text: WC.dom.fmtKickoff(m.dateUtc)
    }));
    var t = el('span', 'sx-teams');
    t.appendChild(crest(m.home, 'crest-sx'));
    t.appendChild(el('span', {
      class: 'sx-abbr',
      text: m.home.abbr || teamName(m.home)
    }));
    t.appendChild(el('span', {
      class: 'sx-v',
      text: 'v'
    }));
    t.appendChild(crest(m.away, 'crest-sx'));
    t.appendChild(el('span', {
      class: 'sx-abbr',
      text: m.away.abbr || teamName(m.away)
    }));
    row.appendChild(t);
    return row;
  }
  function resultRow(m) {
    var row = el('div', 'sx-row is-result');
    var t = el('span', 'sx-teams');
    t.appendChild(crest(m.home, 'crest-sx'));
    t.appendChild(el('span', {
      class: 'sx-abbr' + (m.home.winner ? ' is-win' : ''),
      text: m.home.abbr || teamName(m.home)
    }));
    t.appendChild(el('span', {
      class: 'sx-score',
      text: (m.home.score || '0') + '–' + (m.away.score || '0')
    }));
    t.appendChild(el('span', {
      class: 'sx-abbr' + (m.away.winner ? ' is-win' : ''),
      text: m.away.abbr || teamName(m.away)
    }));
    row.appendChild(t);
    return row;
  }
  function col(title, rows, emptyText) {
    var c = el('div', 'card-col');
    c.appendChild(el('div', {
      class: 'col-title',
      text: title
    }));
    if (!rows.length) {
      c.appendChild(el('div', {
        class: 'card-empty',
        text: emptyText
      }));
    } else {
      var body = el('div', 'col-body');
      rows.forEach(function (r) {
        body.appendChild(r);
      });
      c.appendChild(body);
    }
    return c;
  }

  // --- Head / foot --------------------------------------------------------
  function head(view, cfg) {
    var h = el('div', 'card-head');
    h.appendChild(el('div', {
      class: 'card-title',
      text: cfg && cfg.title || 'World Cup'
    }));
    var label = el('div', 'card-label');
    if (view.mode === 'live') {
      label.classList.add('is-live');
      label.appendChild(el('span', 'live-dot'));
      label.appendChild(el('span', {
        text: view.live.length > 1 ? view.live.length + ' LIVE' : 'LIVE'
      }));
    } else {
      label.appendChild(el('span', {
        text: view.dayLabel
      }));
    }
    h.appendChild(label);
    return h;
  }
  function foot(meta) {
    meta = meta || {};
    if (!meta.savedAt) return null;
    var f = el('div', 'card-foot' + (meta.stale ? ' is-stale' : ''));
    f.textContent = (meta.stale ? 'Offline · ' : '') + WC.dom.relTime(meta.savedAt);
    return f;
  }

  // --- Top-level render ---------------------------------------------------
  function render(root, view, cfg, meta) {
    root.classList.remove('is-loading');
    ['state-live', 'state-today', 'state-next'].forEach(function (c) {
      root.classList.remove(c);
    });
    root.classList.add('state-' + view.mode);
    WC.dom.clear(root);
    root.appendChild(head(view, cfg));
    var hero = el('div', 'card-hero');
    if (view.mode === 'live' && view.focus) hero.appendChild(liveHero(view.focus));else hero.appendChild(fixturesHero(view));
    root.appendChild(hero);
    var sec = el('div', 'card-secondary');
    if (view.mode === 'live') {
      sec.appendChild(col('Up next', view.upcoming.slice(0, 5).map(fixtureRow), 'No more today'));
      sec.appendChild(col('Recent', view.recent.slice(0, 5).map(resultRow), 'No results yet'));
    } else if (view.recent.length) {
      sec.appendChild(col('Recent results', view.recent.slice(0, 6).map(resultRow), ''));
    }
    if (sec.childNodes.length) root.appendChild(sec);
    var f = foot(meta);
    if (f) root.appendChild(f);
  }
  WC.cardRender = {
    render: render
  };
})();
;
/* scores-card/js/main.js */
/* main.js — orchestration for the World Cup scores card.
 * config → poller(fetchView) → classify → render, cache-first, with a fast/slow
 * cadence that follows whether anything is live, and a rotation timer that cycles
 * the hero focus when more than one match is live. */
(function () {
  'use strict';

  var WC = window.WC || {};
  var el = WC.dom.el;
  var CACHE_KEY = 'wc:card:scores:day';
  var FAST_MS = 45000; // refresh while live / about to kick off
  var SLOW_MS = 300000; // idle refresh
  var ROTATE_MS = 10000; // hero focus cycle when >1 live

  var root = document.getElementById('card');
  var st = {
    cfg: null,
    view: null,
    focusIndex: 0,
    poller: null,
    rotateTimer: null,
    savedAt: null,
    stale: false
  };
  function applyAccent(hex) {
    if (!hex) return;
    var r = document.documentElement;
    r.style.setProperty('--wc-accent', hex);
    r.style.setProperty('--wc-accent-dark', hex);
  }

  // Attach the currently-focused live match to the view (rotates when >1 live).
  function focusedView() {
    var v = st.view;
    if (!v) return v;
    var focus = v.mode === 'live' && v.live.length ? v.live[st.focusIndex % v.live.length] : null;
    return Object.assign({}, v, {
      focus: focus
    });
  }
  function paint() {
    if (!st.view) return;
    WC.cardRender.render(root, focusedView(), st.cfg, {
      savedAt: st.savedAt,
      stale: st.stale
    });
  }
  function setupRotation() {
    clearInterval(st.rotateTimer);
    st.rotateTimer = null;
    if (st.view && st.view.mode === 'live' && st.view.live.length > 1) {
      st.rotateTimer = setInterval(function () {
        st.focusIndex += 1;
        paint();
      }, ROTATE_MS);
    }
  }
  function applyDay(day, stale, savedAt) {
    st.stale = !!stale;
    st.savedAt = savedAt;
    st.view = WC.cardState.classify(day);
    if (st.focusIndex >= Math.max(st.view.live.length, 1)) st.focusIndex = 0;
    paint();
    setupRotation();
  }
  function onData(day) {
    var entry = WC.cache.set(CACHE_KEY, day);
    applyDay(day, false, entry.savedAt);
  }
  function onError() {
    var cached = WC.cache.get(CACHE_KEY);
    if (cached && cached.data) {
      applyDay(cached.data, true, cached.savedAt);
    } else {
      WC.dom.clear(root);
      root.classList.remove('is-loading');
      root.appendChild(el('div', {
        class: 'card-empty card-fatal',
        text: 'Scores unavailable'
      }));
    }
  }
  function startPoller() {
    st.poller = WC.poller.create({
      fetchFn: WC.cardState.fetchView,
      isFastFn: WC.cardState.isFast,
      fastMs: FAST_MS,
      slowMs: SLOW_MS,
      onData: onData,
      onError: onError
    });
    st.poller.start();
  }
  function init() {
    WC.espn.configureFromUrl();
    // Namespace the cache by data source so dev mocks (and any multi-instance
    // use) don't share one key. Production (no mock) keeps the single key.
    var mock = WC.espn._config && WC.espn._config.mockName;
    if (mock) CACHE_KEY += ':' + mock;
    WC.cardConfig.load(function (updated) {
      st.cfg = updated;
      applyAccent(updated.accentColor);
      if (st.view) paint();
    }).then(function (cfg) {
      st.cfg = cfg;
      applyAccent(cfg.accentColor);
      // Cache-first paint so a player shows something instantly after a reboot.
      var cached = WC.cache.get(CACHE_KEY);
      if (cached && cached.data) applyDay(cached.data, false, cached.savedAt);
      startPoller();
    });
  }
  init();
})();